<?php declare(strict_types = 1);

namespace Contributte\Console\Exception\Runtime;

use Contributte\Console\Exception\RuntimeException;

class CommandNotFoundException extends RuntimeException
{

}
