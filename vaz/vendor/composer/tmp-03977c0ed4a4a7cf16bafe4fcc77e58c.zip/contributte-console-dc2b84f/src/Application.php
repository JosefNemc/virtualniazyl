<?php declare(strict_types = 1);

namespace Contributte\Console;

use Symfony\Component\Console\Application as ConsoleApplication;

class Application extends ConsoleApplication
{

}
