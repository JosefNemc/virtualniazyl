<?php declare(strict_types = 1);

namespace Contributte\Console\Exception;

use LogicException;

class LogicalException extends LogicException
{

}
